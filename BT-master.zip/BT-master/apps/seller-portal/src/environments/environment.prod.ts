export const environment = {
  production: true,
  enforceHttps: true,
};
