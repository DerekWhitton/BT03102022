export const environment = {
  production: false,
  enforceHttps: false,
};
