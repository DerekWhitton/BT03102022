export * from './lib/administration-portal-articles.module';
