import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bushtrade-administration-articles-index',
  templateUrl: './articles-index.component.html',
  styleUrls: ['./articles-index.component.scss'],
})
export class ArticlesIndexComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
