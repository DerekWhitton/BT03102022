import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bushtrade-administration-messages-index',
  templateUrl: './messages-index.component.html',
  styleUrls: ['./messages-index.component.scss']
})
export class MessagesIndexComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
