# administration-portal-messages

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test administration-portal-messages` to execute the unit tests.
