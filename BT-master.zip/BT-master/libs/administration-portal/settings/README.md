# administration-portal-settings

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test administration-portal-settings` to execute the unit tests.
