import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bushtrade-administration-dashboard-index',
  templateUrl: './dashboard-index.component.html',
  styleUrls: ['./dashboard-index.component.scss']
})
export class DashboardIndexComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
