import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bushtrade-administration-reports-index',
  templateUrl: './reports-index.component.html',
  styleUrls: ['./reports-index.component.scss']
})
export class ReportsIndexComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
