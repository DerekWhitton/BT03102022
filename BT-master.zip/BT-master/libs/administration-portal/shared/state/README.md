# administration-portal-shared-state

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `ng test administration-portal-shared-state` to execute the unit tests via [Jest](https://jestjs.io).
