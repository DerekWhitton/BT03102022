export interface ITopic {
  id: string;
  name: string;
}
