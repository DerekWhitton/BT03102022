export enum PackageType {
  'Top Ad',
  'Highlight Ad',
  'Urgent Ad',
  'Homepage Ad',
  'Hyperlink Ad'
}
