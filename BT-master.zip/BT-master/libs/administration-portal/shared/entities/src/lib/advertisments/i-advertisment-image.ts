export interface IAdvertismentImage {
  imageUri: string
}