export interface IDashboardAdvertisment {
  id: string;
  title: string;
  label: string;
  link: string;
  imageUri: string;
  isActive: boolean;
}