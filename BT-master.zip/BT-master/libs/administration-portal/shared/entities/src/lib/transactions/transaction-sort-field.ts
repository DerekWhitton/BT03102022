export enum TransactionSortField {
  NetAmount,
  GrossAmount,
  FeeAmount,
  CreatedDate,
}
