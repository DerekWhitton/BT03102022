export interface ICreateSupportTicketMessage {
  supportTicketId: string;
  message: string;
}
