export interface ISupportTicketMessage {
  id: string;
  name: string;
  isAdmin: boolean;
  message: string;
  createdAt: string;
}
