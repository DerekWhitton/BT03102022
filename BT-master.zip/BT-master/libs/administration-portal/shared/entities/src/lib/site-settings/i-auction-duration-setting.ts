export interface IAuctionDurationSetting {
  id: string,
  isActive: boolean,
  numberOfDays: number,
  createdAt: Date
}