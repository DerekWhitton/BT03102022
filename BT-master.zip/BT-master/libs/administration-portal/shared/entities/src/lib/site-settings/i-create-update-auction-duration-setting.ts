export interface ICreateOrUpdateAuctionDurationSetting {
  id: string,
  isActive: boolean,
  numberOfDays: boolean
}