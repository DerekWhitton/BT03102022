export enum SortOrder {
  Ascending,
  Descending
}