# administration-portal-shared-entities

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `ng test administration-portal-shared-entities` to execute the unit tests via [Jest](https://jestjs.io).
