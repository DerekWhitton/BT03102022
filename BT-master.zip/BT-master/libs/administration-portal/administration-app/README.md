# administration-portal-administration-app

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test administration-portal-administration-app` to execute the unit tests.
