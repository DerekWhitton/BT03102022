export * from './lib/administration-portal-administration-app.module';
