# administration-portal-advertisments

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test administration-portal-advertisments` to execute the unit tests.
